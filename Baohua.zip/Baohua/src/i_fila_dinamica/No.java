package i_fila_dinamica;


public class No {
    String elemento;
    No proximo;
}
