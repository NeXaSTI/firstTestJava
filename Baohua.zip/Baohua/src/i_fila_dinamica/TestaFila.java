package i_fila_dinamica;
import java.util.Scanner;


public class TestaFila {
    public static void main(String[] args){
        Scanner ler = new Scanner(System.in);
        FilaDinamica fila = new FilaDinamica();
        String Caminho = "src/entrada/Entrada.txt";
        Arquivo.Start(Caminho, fila);
        String op;
    
do{
    System.out.printf("\n\n");
    System.out.printf("    *=======================  Fila   =========================*\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |         A - INSERIR                   B - REMOVER              |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |         C - BUSCAR                    D - IMPRIMIR             |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |         E - VOLTAR                                             |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |                        S - SAIR                                |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    |                                                                |\n");
    System.out.printf("    ==================================================================\n");
    System.out.printf("\n    Digite...: ");
    op = ler.next().toUpperCase();
        switch(op){
            
            case "A":
                do{
                    System.out.printf("\n");
                    System.out.printf("----- INSERIR DADOS -----");
                    System.out.printf("C - Continuar");
                    System.out.printf("\n");                    
                    System.out.printf("D - VOLTAR");
                    System.out.printf("\n");
                    System.out.printf("\n");
                    System.out.printf("Digite a opcao: ");
                    op = ler.next().toUpperCase();
                    
              if(op.contains("C")){
                System.out.println("Digite um nome:");
                String dados = ler.next();
                fila.inserir_dado_final(dados, Caminho);
                System.out.println("Inserido com sucesso!");
              }
       
              }while(op.contains("D")==false);
           break;     
           
            case "B":
                do{
                    System.out.printf("\n");
                    System.out.printf("----- REMOVER DADOS -----");
                    System.out.printf("\n");
                    System.out.printf("C - CONTINUAR");
                    System.out.printf("\n");                    
                    System.out.printf("D - VOLTAR");
                    System.out.printf("\n");
                    System.out.printf("\n");
                    System.out.printf("Digite a opcao: ");
                    op = ler.next().toUpperCase();
                    
              if(op.contains("C")){
                 //lista.remover_lista_final(); 
                 Arquivo.remover(Caminho, fila); 
              }
       
              }while(op.contains("D")==false);
             break;    
             
        case "C":
            do{
                    System.out.printf("\n");
                    System.out.printf("----- BUSCAR DADOS -----");
                    System.out.printf("\n");
                    System.out.printf("A - BUSCAR FILA");
                    System.out.printf("\n");
                    System.out.printf("B - VOLTAR");
                    System.out.printf("\n");
                    System.out.printf("\n");
                    System.out.printf("Digite a opcao: ");
                    op = ler.next().toUpperCase();
                    
              if(op.contains("A")){
                System.out.println("Digite o nome da pessoa:");
                String busca = ler.next();
                fila.buscarFila(busca);   
              }

              }while(op.contains("B")==false);
             break;  
             
        case "D":
            do{
                    System.out.printf("\n");
                    System.out.printf("----- IMPRIMIR DADOS -----");
                    System.out.printf("\n");
                    System.out.printf("A - IMPRIMIR FILA");
                    System.out.printf("\n");
                    System.out.printf("B - VOLTAR");
                    System.out.printf("\n");
                    System.out.printf("\n");
                    System.out.printf("Digite a opcao: ");
                    op = ler.next().toUpperCase();
                    
              if(op.contains("A")){
                fila.imprimirFila();
              }

              }while(op.contains("B")==false);
            break;    
              }
    }while(op.contains("S")==false);
        System.out.printf("fim\n");
    }
}
