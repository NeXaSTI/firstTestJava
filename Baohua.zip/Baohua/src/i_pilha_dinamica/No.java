package i_pilha_dinamica;

class No {
    String dados;
    No proximo;
}
