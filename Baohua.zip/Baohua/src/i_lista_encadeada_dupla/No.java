package i_lista_encadeada_dupla;

class No {
    String dados;
    No proximo;
    No anterior;
}
